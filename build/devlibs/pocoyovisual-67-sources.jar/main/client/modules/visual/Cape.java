package main.client.modules.visual;

import main.client.module.Category;
import main.client.module.Module;
import main.client.setting.ColorSetting;
import net.minecraft.util.Identifier;

public class Cape extends Module {
    private static final Identifier CAPE_TEXTURE = Identifier.of("pocou", "texture/cape.png");

    private final ColorSetting color = new ColorSetting("Color", 0xFFFFFFFF);

    public Cape() {
        super("Cape", Category.VISUAL, "отображает плащ на игроке");
        addSettings(color);
    }

    public ColorSetting getColor() {
        return color;
    }

    public Identifier getCapeTexture() {
        return CAPE_TEXTURE;
    }
}
