package main.mixin;

import main.client.util.VisualUtils;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_10017;
import net.minecraft.class_10055;
import net.minecraft.class_2561;
import net.minecraft.class_897;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

@Environment(EnvType.CLIENT)
@Mixin(class_897.class)
public abstract class EntityRendererMixin<S extends class_10017> {

    /**
     * Модифицируем аргумент 'text' (Text) перед самой отрисовкой метки.
     * Это не затрагивает RenderState и гарантирует отсутствие StackOverflowError.
     */
    @ModifyVariable(
            method = "renderLabelIfPresent",
            at = @At("HEAD"),
            argsOnly = true
    )
    private class_2561 modifyLabelText(class_2561 text, S state) {
        if (state instanceof class_10055 playerState) {
            String rawName = playerState.field_53529;

            // Проверяем имя через утилиту
            if (rawName != null && VisualUtils.isPagatosik(rawName)) {
                // Если имя подходит, возвращаем кастомный Text с красным цветом (или другим форматированием)
                return class_2561.method_43470("§c" + rawName);
            }
        }
        return text;
    }
}