package main.mixin;

import java.util.Map;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1113;
import net.minecraft.class_1140;
import net.minecraft.class_1140.class_11518;
import net.minecraft.class_4235.class_4236;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
// import ru.noxium.Noxium;
// import ru.noxium.module.impl.visuals.RTXSounds;

@Environment(EnvType.CLIENT)
@Mixin({class_1140.class})
public abstract class SoundSystemMixin {
   @Shadow
   private Map<class_1113, class_4236> sources;

   @Inject(
      method = {"play"},
      at = {@At("RETURN")}
   )
   private void onSoundPlay(class_1113 sound, CallbackInfoReturnable<class_11518> cir) {
      // if (Noxium.get.manager.getModule(RTXSounds.class).enable) {
      //    if (Noxium.rtx == null) {
      //       return;
      //    }

      //    try {
      //       SourceManager sourceManager = this.sources.get(sound);
      //       if (sourceManager != null) {
      //          sourceManager.run(source -> {
      //             try {
      //                int sourceId = ((SourceAccessor)source).rtx$getSourceId();
      //                if (sourceId > 0) {
      //                   Noxium.rtx.getMixer().injectFiltersToChannel(sound, sourceId);
      //                }
      //             } catch (Exception var3x) {
      //             }
      //          });
      //       }
      //    } catch (Exception var4) {
      //    }
      // }
   }
}
