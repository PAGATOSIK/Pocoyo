package main.mixin;

import net.minecraft.class_1657;
import net.minecraft.class_2561;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_1657.class)
public abstract class PlayerEntityMixin {

    @Inject(method = "getName", at = @At("HEAD"), cancellable = true)
    private void onGetName(CallbackInfoReturnable<class_2561> cir) {
        class_1657 self = (class_1657) (Object) this;

        // ВАЖНО: Не вызывайте self.getName() здесь!
        // Используем GameProfile, чтобы получить исходное имя без рекурсии:
        String rawName = self.method_7334().getName();

        if ("PAGATOSIK".equals(rawName)) {
            // Возвращаем измененный Text и отменяем оригинальный метод
            cir.setReturnValue(class_2561.method_43470("§c" + rawName));
        }
    }
}