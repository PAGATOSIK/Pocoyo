package main.mixin;

import main.client.PocoyoVisual;
import main.client.modules.game.WorldTime;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_310;
import net.minecraft.class_638;
import net.minecraft.class_761;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Environment(EnvType.CLIENT)
@Mixin(class_761.class)
public class WorldMixin {

    private long originalTime = -1;

    @Inject(method = "render", at = @At("HEAD"))
    private void onRenderStart(CallbackInfo ci) {
        WorldTime worldTime = PocoyoVisual.INSTANCE.getModuleManager().getModule(WorldTime.class);
        if (worldTime != null && worldTime.isToggled()) {
            class_638 world = class_310.method_1551().field_1687;
            if (world != null) {
                long customTime = worldTime.getCustomTime();
                if (customTime >= 0) {
                    originalTime = world.method_8532();
                    // Меняем время через свойства уровня клиента
                    world.method_28104().method_165(customTime);
                }
            }
        }
    }

    @Inject(method = "render", at = @At("RETURN"))
    private void onRenderEnd(CallbackInfo ci) {
        if (originalTime >= 0) {
            class_638 world = class_310.method_1551().field_1687;
            if (world != null) {
                // Возвращаем оригинальное время обратно
                world.method_28104().method_165(originalTime);
            }
            originalTime = -1;
        }
    }
}