package main.mixin;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_11223;
import net.minecraft.class_1657;
import net.minecraft.class_327;
import net.minecraft.class_329;
import net.minecraft.class_332;
import net.minecraft.class_9779;
import main.client.hud.HudRenderer;
import main.client.PocoyoVisual;
import main.client.modules.visual.TargetEsp;
import org.lwjgl.opengl.GL11;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
// import ru.noxium.Noxium;
// import ru.noxium.event.EventManager;
// import ru.noxium.event.impl.EventScreen;
// import ru.noxium.module.impl.visuals.Hud;
// import ru.noxium.module.impl.visuals.HUD.TargetHUD;
// import ru.noxium.module.impl.visuals.HUD.HotBarHUD;
// import ru.noxium.module.impl.visuals.HUD.CoolDowns;
// import ru.noxium.ui.draggable.DraggableManager;
// import ru.noxium.util.render.animation.AnimationSystem;
// import ru.noxium.util.render.backends.gl.GlState;
// import ru.noxium.util.render.core.Renderer2D;
// import ru.noxium.util.render.text.FontRegistry;

@Environment(EnvType.CLIENT)
@Mixin({ class_329.class })
public class InGameHudMixin {
   @Inject(method = { "renderStatusEffectOverlay" }, at = { @At("HEAD") }, cancellable = true)
   private void onRenderStatusEffects(class_332 context, class_9779 tickCounter, CallbackInfo ci) {
      // if (Hud.element.get("Список зелий")) {
      //    ci.cancel();
      // }
   }

   @Inject(method = { "renderHotbar" }, at = { @At("HEAD") }, cancellable = true)
   private void onRenderHotbar(class_332 context, class_9779 tickCounter, CallbackInfo ci) {
      // if (Hud.element.get("Хот бар")) {
      //    ci.cancel();
      // }
   }

   @Inject(method = { "renderHealthBar" }, at = { @At("HEAD") }, cancellable = true)
   private void onRenderHealthBar(
         class_332 context,
         class_1657 player,
         int x,
         int y,
         int lines,
         int regeneratingHeartIndex,
         float maxHealth,
         int lastHealth,
         int health,
         int absorption,
         boolean blinking,
         CallbackInfo ci) {
      // if (Hud.element.get("Хот бар")) {
      //    ci.cancel();
      // }
   }

   @Inject(method = { "renderFood" }, at = { @At("HEAD") }, cancellable = true)
   private void onRenderFood(class_332 context, class_1657 player, int top, int right, CallbackInfo ci) {
      // if (Hud.element.get("Хот бар")) {
      //    ci.cancel();
      // }
   }

   @Inject(method = { "renderFood" }, at = { @At("TAIL") })
   private void onRenderFoodTail(class_332 context, class_1657 player, int top, int right, CallbackInfo ci) {
      // if (!Hud.element.get("Хот бар")) {
      //    HotBarHUD.renderSaturation(context, player, top - 10, right, player.getHungerManager().getSaturationLevel());
      // }
   }

   @Inject(method = { "renderArmor" }, at = { @At("HEAD") }, cancellable = true)
   private static void onRenderArmor(class_332 context, class_1657 player, int i, int j, int k, int x,
         CallbackInfo ci) {
      // if (Hud.element.get("Хот бар")) {
      //    ci.cancel();
      // }
   }

   @Inject(method = { "renderAirBubbles" }, at = { @At("HEAD") }, cancellable = true)
   private void onRenderAir(class_332 context, class_1657 player, int heartCount, int top, int left,
         CallbackInfo ci) {
      // if (Hud.element.get("Хот бар")) {
      //    ci.cancel();
      // }
   }

   @Inject(method = { "renderMountHealth" }, at = { @At("HEAD") }, cancellable = true)
   private void onRenderMountHealth(class_332 context, CallbackInfo ci) {
      // if (Hud.element.get("Хот бар")) {
      //    ci.cancel();
      // }
   }

   @Redirect(method = {
         "renderMainHud" }, at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/hud/bar/Bar;drawExperienceLevel(Lnet/minecraft/client/gui/DrawContext;Lnet/minecraft/client/font/TextRenderer;I)V"))
   private void redirectDrawExperienceLevel(class_332 context, class_327 textRenderer, int level) {
      // if (!Hud.element.get("Хот бар")) {
         class_11223.method_70866(context, textRenderer, level);
      // }
   }

   @Redirect(method = {
         "renderMainHud" }, at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/hud/bar/Bar;renderBar(Lnet/minecraft/client/gui/DrawContext;Lnet/minecraft/client/render/RenderTickCounter;)V", ordinal = 0))
   private void redirectRenderBar(class_11223 bar, class_332 context, class_9779 tickCounter) {
      // if (!Hud.element.get("Хот бар")) {
         bar.method_70865(context, tickCounter);
      // }
   }

   @Redirect(method = {
         "renderMainHud" }, at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/hud/bar/Bar;renderAddons(Lnet/minecraft/client/gui/DrawContext;Lnet/minecraft/client/render/RenderTickCounter;)V", ordinal = 0))
   private void redirectRenderAddons(class_11223 bar, class_332 context, class_9779 tickCounter) {
      // if (!Hud.element.get("Хот бар")) {
         bar.method_70868(context, tickCounter);
      // }
   }

   @Inject(method = { "render" }, at = { @At("RETURN") })
   private void onRenderHud(class_332 context, class_9779 tickCounter, CallbackInfo ci) {
      HudRenderer.draw(context, tickCounter.method_60637(true));
   }

   private static void setEnabled(int cap, boolean enabled) {
      if (enabled) {
         GL11.glEnable(cap);
      } else {
         GL11.glDisable(cap);
      }
   }
}
