package main.mixin;

import main.client.PocoyoVisual;
import main.client.modules.visual.Cape;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_10055;
import net.minecraft.class_2960;
import net.minecraft.class_972;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Environment(EnvType.CLIENT)
@Mixin(class_972.class)
public abstract class CapeFeatureRendererMixin {

    private static final class_2960 CUSTOM_CAPE = class_2960.method_60655("pocou", "texture/cape.png");

    @Inject(
            method = "getTexture",
            at = @At("HEAD"),
            cancellable = true
    )
    private void getCustomCapeTexture(class_10055 state, CallbackInfoReturnable<class_2960> cir) {
        Cape cape = PocoyoVisual.INSTANCE.getModuleManager().getModule(Cape.class);
        if (cape != null && cape.isToggled()) {
            cir.setReturnValue(CUSTOM_CAPE);
        }
    }
}
