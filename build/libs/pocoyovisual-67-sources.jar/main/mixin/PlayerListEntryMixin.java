package main.mixin;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2561;
import net.minecraft.class_5250;
import net.minecraft.class_640;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import main.client.util.VisualUtils;

@Environment(EnvType.CLIENT)
@Mixin({ class_640.class })
public abstract class PlayerListEntryMixin {

    @Inject(method = "getDisplayName", at = @At("HEAD"), cancellable = true)
    private void onGetDisplayName(CallbackInfoReturnable<class_2561> cir) {
        try {
            class_640 entry = (class_640)(Object)this;
            if (entry != null && entry.method_2966() != null) {
                String playerName = entry.method_2966().getName();
                System.out.println("[PlayerListEntry] Checking player: " + playerName); // Debug
                if (VisualUtils.isPagatosik(playerName)) {
                    System.out.println("[PlayerListEntry] PAGATOSIK found! Creating red text"); // Debug
                    class_5250 coloredText = class_2561.method_43470(playerName)
                        .method_27694(style -> style.method_36139(0xFF5555));
                    cir.setReturnValue(coloredText);
                    return;
                }
            }
            // Если не PAGATOSIK, не отменяем оригинальный метод
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
