package main.mixin;

import main.client.PocoyoVisual;
import main.client.gui.ClickGuiScreen;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_309;
import net.minecraft.class_310;
import org.lwjgl.glfw.GLFW;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Environment(EnvType.CLIENT)
@Mixin({class_309.class})
public class KeyboardMixin {

    @Inject(
            method = {"onKey"},
            at = {@At("HEAD")},
            cancellable = true
    )
    private void handleMenuKeyEvent(long window, int key, int scanCode, int action, int modifiers, CallbackInfo ci) {
        class_310 client = class_310.method_1551();

        if (client.field_1724 == null || client.method_22683() == null) return;

        if (action == 1) {

            if (key == GLFW.GLFW_KEY_RIGHT_SHIFT || key == GLFW.GLFW_KEY_Y) {

                if (client.field_1755 == null) {
                    client.execute(() -> client.method_1507(new ClickGuiScreen()));
                    ci.cancel();
                }
            }
        }
    }
}