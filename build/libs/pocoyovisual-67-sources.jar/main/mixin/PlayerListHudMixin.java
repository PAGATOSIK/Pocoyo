package main.mixin;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_266;
import net.minecraft.class_269;
import net.minecraft.class_332;
import net.minecraft.class_355;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Environment(EnvType.CLIENT)
@Mixin(class_355.class)
public abstract class PlayerListHudMixin {

    @Inject(
            method = "render",
            at = @At("HEAD")
    )
    private void onRenderHead(
            class_332 context,
            int scaledWidth,
            class_269 scoreboard,
            @Nullable class_266 objective,
            CallbackInfo ci
    ) {
        System.out.println("[PlayerListHud] render HEAD called");
    }
}