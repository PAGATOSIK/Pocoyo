package main.mixin;

import main.client.PocoyoVisual;
import main.client.modules.visual.Cape;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2960;
import net.minecraft.class_742;
import net.minecraft.class_8685;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Environment(EnvType.CLIENT)
@Mixin(class_742.class)
public abstract class AbstractClientPlayerEntityMixin {

    @Inject(method = "getSkinTextures", at = @At("RETURN"), cancellable = true)
    private void onGetSkinTextures(CallbackInfoReturnable<class_8685> cir) {
        class_742 player = (class_742) (Object) this;

        Cape cape = PocoyoVisual.INSTANCE.getModuleManager().getModule(Cape.class);
        if (cape != null && cape.isToggled()) {
            class_2960 customCape = cape.getCapeTexture();

            if (customCape != null) {
                class_8685 original = cir.getReturnValue();
                cir.setReturnValue(new class_8685(
                        original.comp_1626(),
                        original.comp_1911(),
                        customCape,
                        customCape,
                        original.comp_1629(),
                        original.comp_1630()
                ));
            }
        }
    }
}
