package main.client.manager;

import java.awt.Font;
import java.io.InputStream;
import net.minecraft.class_2960;
import net.minecraft.class_310;

public class FontManager {

    // Сюда можно добавить кастомные обертки над текстурами (например, CustomFontRenderer)
    // Для базового старта определим метод загрузки TTF из ассетов мода

    public void init() {
        // Пример загрузки шрифта из resources/assets/pocoyovisual/fonts/font.ttf
        try {
            class_2960 fontLocation = class_2960.method_60655("pocoyovisual", "fonts/font.ttf");
            InputStream is = class_310.method_1551().method_1478()
                    .method_14486(fontLocation)
                    .orElseThrow()
                    .method_14482();

            Font baseFont = Font.createFont(Font.TRUETYPE_FONT, is);
            Font clientFont = baseFont.deriveFont(18f); // Размер шрифта

            // Здесь должна быть генерация текстурного атласа для глифов (символов)

        } catch (Exception e) {
            System.err.println("Не удалось загрузить кастомный шрифт, используем ванильный.");
            e.printStackTrace();
        }
    }
}