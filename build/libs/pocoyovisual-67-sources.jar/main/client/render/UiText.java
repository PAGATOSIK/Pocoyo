package main.client.render;

import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_2960;

/** Text used by the client UI, kept separate from Minecraft's default font. */
public final class UiText {
    /** The bundled display font used by every custom client label. */
    private static final class_2960 UI_FONT = class_2960.method_60655("pocou", "sf-pro-text-11");

    private UiText() {
    }

    public static class_2561 of(String value) {
        return class_2561.method_43470(value).method_10862(class_2583.field_24360.method_27704(UI_FONT));
    }
}
