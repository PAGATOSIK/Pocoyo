package main.client.render;

import net.minecraft.class_1041;
import net.minecraft.class_310;
import org.lwjgl.opengl.GL11;

public class Scissor {
    public static void push() {
        GL11.glEnable(GL11.GL_SCISSOR_TEST);
    }

    public static void pop() {
        GL11.glDisable(GL11.GL_SCISSOR_TEST);
    }

    public static void set(int x, int y, int width, int height) {
        class_310 mc = class_310.method_1551();
        class_1041 window = mc.method_22683();

        // В современных версиях scaleFactor берется из объекта Window
        double scale = window.method_4495();

        int scissorX = (int) (x * scale);
        int scissorY = (int) ((window.method_4502() - (y + height)) * scale);
        int scissorWidth = (int) (width * scale);
        int scissorHeight = (int) (height * scale);

        GL11.glScissor(scissorX, scissorY, Math.max(0, scissorWidth), Math.max(0, scissorHeight));
    }
}