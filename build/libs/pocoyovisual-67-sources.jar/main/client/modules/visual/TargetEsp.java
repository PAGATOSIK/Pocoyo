package main.client.modules.visual;

import main.client.module.Category;
import main.client.module.Module;
import main.client.setting.ColorSetting;
import net.minecraft.class_1297;
import net.minecraft.class_1921;
import net.minecraft.class_243;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_4608;
import net.minecraft.class_7833;
import org.joml.Matrix4f;

public class TargetEsp extends Module {
    private static final class_2960 TARGET_TEXTURE = class_2960.method_60655("pocou", "texture/target.png");

    private final float size = 28.0F;
    private class_1297 target;
    private float rotationAngle = 0.0F;
    private float rotationSpeed = 0.5F;
    private boolean isReversing = false;
    private float animProgress = 0.0F;
    private final ColorSetting color = new ColorSetting("Color", 0xFFFFFFFF);

    public TargetEsp() {
        super("Target ESP", Category.VISUAL, "отображает цель с эффектом вращения");
        addSettings(color);
    }

    public void onAttack(class_1297 entity) {
        if (isToggled() && entity != null && entity.method_5805()) {
            this.target = entity;
        }
    }

    public class_1297 getActiveTarget() {
        if (target == null || !target.method_5805()) {
            target = null;
        }
        return target;
    }

    public void onTick() {
        boolean active = getActiveTarget() != null && isToggled();

        if (active) {
            animProgress = Math.min(1.0F, animProgress + 0.1F);
        } else {
            animProgress = Math.max(0.0F, animProgress - 0.1F);
        }

        if (animProgress > 0.01F) {
            updateRotation();
        }
    }

    private void updateRotation() {
        if (!this.isReversing) {
            this.rotationSpeed += 0.01F;
            if ((double) this.rotationSpeed > 2.3D) {
                this.rotationSpeed = 2.3F;
                this.isReversing = true;
            }
        } else {
            this.rotationSpeed -= 0.01F;
            if ((double) this.rotationSpeed < -2.3D) {
                this.rotationSpeed = -2.3F;
                this.isReversing = false;
            }
        }
        this.rotationAngle += this.rotationSpeed;
        this.rotationAngle %= 360.0F;
    }

    public void render3D(class_4587 matrices, class_4597 consumers, float partialTicks) {
        class_1297 activeTarget = getActiveTarget();
        if (activeTarget == null || animProgress <= 0.01F) return;

        class_310 mc = class_310.method_1551();
        class_4184 camera = mc.field_1773.method_19418();
        class_243 camPos = camera.method_19326();

        class_243 targetPos = activeTarget.method_30950(partialTicks);
        double x = targetPos.field_1352;
        double y = targetPos.field_1351 + (activeTarget.method_17682() / 2.0D);
        double z = targetPos.field_1350;

        matrices.method_22903();
        matrices.method_22904(x - camPos.field_1352, y - camPos.field_1351, z - camPos.field_1350);

        matrices.method_22907(class_7833.field_40716.rotationDegrees(-camera.method_19330()));
        matrices.method_22907(class_7833.field_40714.rotationDegrees(camera.method_19329()));

        matrices.method_22907(class_7833.field_40718.rotationDegrees(this.rotationAngle));

        float scale = 0.05F * size * animProgress;
        matrices.method_22905(-scale, -scale, scale);

        Matrix4f matrix = matrices.method_23760().method_23761();
        int alpha = (int) (animProgress * 255.0F);
        int espColor = color.getColor();
        int r = (espColor >> 16) & 0xFF;
        int g = (espColor >> 8) & 0xFF;
        int b = espColor & 0xFF;

        class_4588 buffer = consumers.getBuffer(class_1921.method_23580(TARGET_TEXTURE));

        drawVertex(buffer, matrix, -0.5F, -0.5F, 0.0F, 0.0F, 1.0F, r, g, b, alpha);
        drawVertex(buffer, matrix, 0.5F, -0.5F, 0.0F, 1.0F, 1.0F, r, g, b, alpha);
        drawVertex(buffer, matrix, 0.5F, 0.5F, 0.0F, 1.0F, 0.0F, r, g, b, alpha);
        drawVertex(buffer, matrix, -0.5F, 0.5F, 0.0F, 0.0F, 0.0F, r, g, b, alpha);

        matrices.method_22909();
    }

    private void drawVertex(class_4588 buffer, Matrix4f matrix, float x, float y, float z, float u, float v, int r, int g, int b, int alpha) {
        buffer.method_22918(matrix, x, y, z)
                .method_1336(r, g, b, alpha)
                .method_22913(u, v)
                .method_22922(class_4608.field_21444)
                .method_60803(0xF000F0)
                .method_22914(0.0F, 0.0F, 1.0F);
    }

    @Override
    protected void onDisable() {
        target = null;
        animProgress = 0.0F;
    }
}