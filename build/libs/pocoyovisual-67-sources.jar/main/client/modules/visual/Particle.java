package main.client.modules.visual;

import main.client.module.Category;
import main.client.module.Module;
import main.client.setting.ModeSetting; // ПРИМЕЧАНИЕ: В вашем клиенте это может называться EnumSetting или ListSetting
import main.client.setting.NumberSetting;
import net.minecraft.class_1297;
import net.minecraft.class_1921;
import net.minecraft.class_243;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_4608;
import net.minecraft.class_7833;
import main.client.setting.ColorSetting;
import org.joml.Matrix4f;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class Particle extends Module {
    private static final class_2960 STAR_TEXTURE = class_2960.method_60655("pocou", "texture/star.png");
    private static final class_2960 HEART_TEXTURE = class_2960.method_60655("pocou", "texture/heart.png");

    private final ModeSetting mode = new ModeSetting("Mode", "Star", "Star", "Heart");
    private final NumberSetting amount = new NumberSetting("Amount", 12.0, 1.0, 100, 1.0);
    private final NumberSetting gravity = new NumberSetting("Gravity", 0.008, 0.001, 0.05, 0.001);
    private final ColorSetting color = new ColorSetting("Color", 0xFFFFFFFF);

    private final List<CustomParticle> particles = new ArrayList<>();
    private final Random random = new Random();

    public Particle() {
        super("Particle", Category.VISUAL, "создает частицы при атаке");
        addSettings(mode, amount, gravity, color);
    }

    public void onAttack(class_1297 target) {
        if (!isToggled() || target == null) return;

        double x = target.method_23317();
        double y = target.method_23318() + target.method_17682() / 2.0;
        double z = target.method_23321();

        int particleCount = (int) amount.getValue();
        double currentGravity = -gravity.getValue();

        for (int i = 0; i < particleCount; i++) {
            particles.add(new CustomParticle(x, y, z, currentGravity, random));
        }
    }

    public void onTick() {
        if (!isToggled()) return;

        particles.removeIf(p -> {
            p.update();
            return p.isDead();
        });
    }

    public void render(class_4587 matrices, class_4597 vertexConsumers, float partialTicks) {
        if (!isToggled() || particles.isEmpty()) return;

        class_310 mc = class_310.method_1551();
        class_4184 camera = mc.field_1773.method_19418();
        class_243 camPos = camera.method_19326();

        class_2960 selectedTexture = mode.getCurrentMode().equalsIgnoreCase("Heart") ? HEART_TEXTURE : STAR_TEXTURE;

        class_4588 buffer = vertexConsumers.getBuffer(class_1921.method_23580(selectedTexture));

        int particleColor = color.getColor();
        int r = (particleColor >> 16) & 0xFF;
        int g = (particleColor >> 8) & 0xFF;
        int b = particleColor & 0xFF;

        for (CustomParticle particle : particles) {
            particle.render(matrices, buffer, camera, camPos, partialTicks, r, g, b);
        }
    }

    public static class CustomParticle {
        private double prevX, prevY, prevZ;
        private double x, y, z;
        private double velocityX, velocityY, velocityZ;

        private final double particleGravity;
        private int life;
        private final int maxLife = 25 + new Random().nextInt(15);
        private final float baseScale = 0.25f + new Random().nextFloat() * 0.25f;

        public CustomParticle(double x, double y, double z, double gravity, Random random) {
            this.x = x;
            this.y = y;
            this.z = z;
            this.prevX = x;
            this.prevY = y;
            this.prevZ = z;
            this.particleGravity = gravity;

            double angle = random.nextDouble() * Math.PI * 2;
            double speed = 0.08 + random.nextDouble() * 0.12;
            double upSpeed = 0.12 + random.nextDouble() * 0.15;

            this.velocityX = Math.cos(angle) * speed;
            this.velocityY = upSpeed;
            this.velocityZ = Math.sin(angle) * speed;

            this.life = maxLife;
        }

        public void update() {
            this.prevX = x;
            this.prevY = y;
            this.prevZ = z;

            velocityY += particleGravity;

            x += velocityX;
            y += velocityY;
            z += velocityZ;

            velocityX *= 0.92;
            velocityY *= 0.92;
            velocityZ *= 0.92;

            life--;
        }

        public boolean isDead() {
            return life <= 0;
        }

        public void render(class_4587 matrices, class_4588 buffer, class_4184 camera, class_243 camPos, float partialTicks, int r, int g, int b) {
            double renderX = class_3532.method_16436(partialTicks, prevX, x);
            double renderY = class_3532.method_16436(partialTicks, prevY, y);
            double renderZ = class_3532.method_16436(partialTicks, prevZ, z);

            float lifeProgress = (float) life / (float) maxLife;
            float alphaProgress = lifeProgress * lifeProgress;
            float scale = baseScale * (float) Math.sin(lifeProgress * Math.PI / 2.0);

            matrices.method_22903();
            matrices.method_22904(renderX - camPos.field_1352, renderY - camPos.field_1351, renderZ - camPos.field_1350);

            matrices.method_22907(class_7833.field_40716.rotationDegrees(-camera.method_19330()));
            matrices.method_22907(class_7833.field_40714.rotationDegrees(camera.method_19329()));

            matrices.method_22905(-scale, -scale, scale);

            Matrix4f matrix = matrices.method_23760().method_23761();
            int alphaInt = (int) (alphaProgress * 255.0f);

            drawVertex(buffer, matrix, -0.5f, -0.5f, 0.0f, 0.0f, 1.0f, r, g, b, alphaInt);
            drawVertex(buffer, matrix, 0.5f, -0.5f, 0.0f, 1.0f, 1.0f, r, g, b, alphaInt);
            drawVertex(buffer, matrix, 0.5f, 0.5f, 0.0f, 1.0f, 0.0f, r, g, b, alphaInt);
            drawVertex(buffer, matrix, -0.5f, 0.5f, 0.0f, 0.0f, 0.0f, r, g, b, alphaInt);

            matrices.method_22909();
        }

        private void drawVertex(class_4588 buffer, Matrix4f matrix, float x, float y, float z, float u, float v, int r, int g, int b, int alpha) {
            buffer.method_22918(matrix, x, y, z)
                    .method_1336(r, g, b, alpha)
                    .method_22913(u, v)
                    .method_22922(class_4608.field_21444)
                    .method_60803(0xF000F0)
                    .method_22914(0.0F, 0.0F, 1.0F);
        }
    }
}