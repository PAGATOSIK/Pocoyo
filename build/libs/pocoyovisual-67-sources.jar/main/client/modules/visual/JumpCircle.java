
package main.client.modules.visual;

import main.client.module.Category;
import main.client.module.Module;
import main.client.setting.NumberSetting;
import net.minecraft.class_1921;
import net.minecraft.class_243;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_4608;
import net.minecraft.class_7833;
import main.client.setting.ColorSetting;
import org.joml.Matrix4f;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class JumpCircle extends Module {

    private static final class_2960 CIRCLE_TEXTURE =
            class_2960.method_60655("pocou", "texture/circle.png");

    private final NumberSetting size =
            new NumberSetting("Size", 1.5, 0.5, 3.0, 0.1);

    private final NumberSetting duration =
            new NumberSetting("Duration", 15.0, 5.0, 30.0, 1.0);

    private final ColorSetting color = new ColorSetting("Color", 0xFFFFFFFF);

    private final List<CircleEffect> circles = new ArrayList<>();

    private boolean wasOnGround = false;
    private boolean initialized = false;

    public JumpCircle() {
        super("JumpCircle", Category.VISUAL, "создает круг при прыжке");
        addSettings(size, duration, color);
    }

    /**
     * Вызывать каждый игровой тик через систему событий клиента.
     */
    public void onTick() {
        if (!isToggled()) {
            circles.clear();
            initialized = false;
            return;
        }

        class_310 mc = class_310.method_1551();

        if (mc.field_1724 == null || mc.field_1687 == null) {
            circles.clear();
            initialized = false;
            return;
        }

        boolean onGround = mc.field_1724.method_24828();

        // Инициализируем состояние, чтобы не создавать круг
        // случайно при первом включении модуля в воздухе.
        if (!initialized) {
            wasOnGround = onGround;
            initialized = true;
        } else {
            // Обнаруживаем переход с земли в воздух.
            if (wasOnGround && !onGround) {
                class_243 pos = mc.field_1724.method_19538();

                circles.add(new CircleEffect(
                        pos.field_1352,
                        pos.field_1351 + 0.03,
                        pos.field_1350,
                        (float) size.getValue(),
                        (int) duration.getValue()
                ));
            }

            wasOnGround = onGround;
        }

        // Обновляем время жизни эффектов.
        Iterator<CircleEffect> iterator = circles.iterator();

        while (iterator.hasNext()) {
            if (iterator.next().update()) {
                iterator.remove();
            }
        }
    }

    /**
     * Вызывать из подходящего события рендеринга мира,
     * передавая актуальные MatrixStack и VertexConsumerProvider.
     */
    public void render(
            class_4587 matrices,
            class_4597 vertexConsumers,
            float partialTicks
    ) {
        if (!isToggled() || circles.isEmpty()) {
            return;
        }

        class_310 mc = class_310.method_1551();

        if (mc.field_1724 == null || mc.field_1687 == null) {
            return;
        }

        class_4184 camera = mc.field_1773.method_19418();
        class_243 cameraPos = camera.method_19326();

        class_4588 buffer = vertexConsumers.getBuffer(
                class_1921.method_23580(CIRCLE_TEXTURE)
        );

        int circleColor = color.getColor();
        int r = (circleColor >> 16) & 0xFF;
        int g = (circleColor >> 8) & 0xFF;
        int b = circleColor & 0xFF;

        for (CircleEffect circle : circles) {
            circle.render(
                    matrices,
                    buffer,
                    cameraPos,
                    partialTicks,
                    r, g, b
            );
        }
    }

    public static class CircleEffect {

        private final double x;
        private final double y;
        private final double z;

        private final float maxRadius;
        private final int maxLife;

        private int life;

        public CircleEffect(
                double x,
                double y,
                double z,
                float maxRadius,
                int maxLife
        ) {
            this.x = x;
            this.y = y;
            this.z = z;
            this.maxRadius = maxRadius;
            this.maxLife = Math.max(1, maxLife);
            this.life = this.maxLife;
        }

        /**
         * Возвращает true, когда эффект нужно удалить.
         */
        public boolean update() {
            life--;
            return life <= 0;
        }

        public void render(
                class_4587 matrices,
                class_4588 buffer,
                class_243 cameraPos,
                float partialTicks,
                int r, int g, int b
        ) {
            float progress = class_3532.method_15363(
                    1.0f - (life - partialTicks) / (float) maxLife,
                    0.0f,
                    1.0f
            );

            // Расширение от центра.
            float currentRadius = maxRadius
                    * class_3532.method_15374(progress * (float) Math.PI / 2.0f);

            // Постепенное исчезновение.
            float alpha = 1.0f - progress;

            if (currentRadius <= 0.001f || alpha <= 0.001f) {
                return;
            }

            matrices.method_22903();

            matrices.method_22904(
                    x - cameraPos.field_1352,
                    y - cameraPos.field_1351,
                    z - cameraPos.field_1350
            );

            // Горизонтальная плоскость.
            matrices.method_22907(
                    class_7833.field_40714.rotationDegrees(90.0f)
            );

            matrices.method_22905(
                    currentRadius * 2.0f,
                    currentRadius * 2.0f,
                    1.0f
            );

            Matrix4f matrix = matrices.method_23760().method_23761();

            int alphaInt = class_3532.method_15340(
                    (int) (alpha * 255.0f),
                    0,
                    255
            );

            // Квадрат с текстурой круга.
            // Порядок вершин рассчитан для обычной текстурной плоскости.
            drawVertex(
                    buffer, matrix,
                    -0.5f, -0.5f, 0.0f,
                    0.0f, 1.0f, r, g, b, alphaInt
            );

            drawVertex(
                    buffer, matrix,
                    0.5f, -0.5f, 0.0f,
                    1.0f, 1.0f, r, g, b, alphaInt
            );

            drawVertex(
                    buffer, matrix,
                    0.5f, 0.5f, 0.0f,
                    1.0f, 0.0f, r, g, b, alphaInt
            );

            drawVertex(
                    buffer, matrix,
                    -0.5f, 0.5f, 0.0f,
                    0.0f, 0.0f, r, g, b, alphaInt
            );

            matrices.method_22909();
        }

        private static void drawVertex(
                class_4588 buffer,
                Matrix4f matrix,
                float x,
                float y,
                float z,
                float u,
                float v,
                int r, int g, int b,
                int alpha
        ) {
            buffer.method_22918(matrix, x, y, z)
                    .method_1336(r, g, b, alpha)
                    .method_22913(u, v)
                    .method_22922(class_4608.field_21444)
                    .method_60803(0xF000F0)
                    .method_22914(0.0f, 0.0f, 1.0f);
        }
    }
}
