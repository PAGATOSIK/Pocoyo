package main.client.modules.visual;

import main.client.module.Category;
import main.client.module.Module;
import main.client.setting.ColorSetting;
import net.minecraft.class_2960;

public class Cape extends Module {
    private static final class_2960 CAPE_TEXTURE = class_2960.method_60655("pocou", "texture/cape.png");

    private final ColorSetting color = new ColorSetting("Color", 0xFFFFFFFF);

    public Cape() {
        super("Cape", Category.VISUAL, "отображает плащ на игроке");
        addSettings(color);
    }

    public ColorSetting getColor() {
        return color;
    }

    public class_2960 getCapeTexture() {
        return CAPE_TEXTURE;
    }
}
