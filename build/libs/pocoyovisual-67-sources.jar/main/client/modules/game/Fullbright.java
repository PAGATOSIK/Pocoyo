package main.client.modules.game;

import main.client.module.Category;
import main.client.module.Module;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_310;

public class Fullbright extends Module {

    public Fullbright() {
        super("Fullbright", Category.GAME, "делает мир максимально ярким");
    }

    public void onTick() {
        if (!isToggled()) return;

        class_310 mc = class_310.method_1551();
        if (mc.field_1724 != null) {
            mc.field_1724.method_6092(new class_1293(
                    class_1294.field_5925,
                    220,
                    0,
                    false,
                    false,
                    false
            ));
        }
    }

    @Override
    public void onDisable() {
        class_310 mc = class_310.method_1551();
        if (mc.field_1724 != null && mc.field_1724.method_6059(class_1294.field_5925)) {
            mc.field_1724.method_6016(class_1294.field_5925);
        }
        super.onDisable();
    }
}