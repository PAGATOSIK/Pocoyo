package main.client.hud;

import main.client.PocoyoVisual;
import main.client.gui.ClickGuiScreen;
import main.client.module.Module;
import net.minecraft.class_310;
import net.minecraft.class_332;
import main.client.manager.ModuleManager;

public class HudRenderer {

    public static void draw(class_332 context, float tickDelta) {
        var mc = class_310.method_1551();

        if (mc.field_1690.field_1842 || mc.field_1755 instanceof ClickGuiScreen) {
            return;
        }

        if (PocoyoVisual.INSTANCE == null) return;
        ModuleManager moduleManager = PocoyoVisual.INSTANCE.getModuleManager();
        if (moduleManager == null) return;

        Module hud = moduleManager.getModules().stream()
                .filter(module -> module.getName().equals("HUD"))
                .findFirst()
                .orElse(null);
        if (hud == null || !hud.isToggled()) return;

        // Вызываем менеджер, который сам отрендерит все активные функции худа
        if (PocoyoVisual.INSTANCE != null && PocoyoVisual.INSTANCE.getHudManager() != null) {
            PocoyoVisual.INSTANCE.getHudManager().renderComponents(context, tickDelta);
        }
    }
}
