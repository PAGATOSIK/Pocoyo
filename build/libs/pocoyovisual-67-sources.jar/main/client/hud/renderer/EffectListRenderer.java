package main.client.hud.renderer;

import main.client.PocoyoVisual;
import main.client.hud.HudComponent;
import main.client.render.RoundedUtils;
import main.client.render.UiText;
import net.minecraft.class_1293;
import net.minecraft.class_310;
import net.minecraft.class_332;
import java.util.ArrayList;
import java.util.List;

public class EffectListRenderer extends HudComponent {

    public EffectListRenderer(int defaultX, int defaultY) {
        super("EffectList", defaultX, defaultY);
    }

    @Override
    public void render(class_332 context, float tickDelta) {
        var mc = class_310.method_1551();
        var textRenderer = mc.field_1772;
        var themeManager = PocoyoVisual.INSTANCE.getThemeManager();

        int x = getX();
        int y = getY();
        int padding = 8;

        context.method_51448().pushMatrix();
        context.method_51448().translate((float) x, (float) y);
        context.method_51448().scale(getScale(), getScale());
        context.method_51448().translate((float) -x, (float) -y);

        try {
            List<class_1293> activeEffects = new ArrayList<>();
            if (mc.field_1724 != null) {
                activeEffects.addAll(mc.field_1724.method_6026());
            }

            if (activeEffects.isEmpty()) {
                return;
            } else {
                renderFullEffectList(context, textRenderer, themeManager, x, y, padding, activeEffects);
            }
        } finally {
            context.method_51448().popMatrix();
        }
    }

    private void renderFullEffectList(class_332 context, net.minecraft.class_327 textRenderer,
                                      main.client.manager.ThemeManager themeManager, int x, int y, int padding,
                                      List<class_1293> activeEffects) {
        int accent = applyAlpha(themeManager.getEffectColor(), getAlpha());
        int textColor = applyAlpha(themeManager.getTextColor(), getAlpha());
        int bgColor = applyAlpha((0xFF << 24) | 0x00141414, getAlpha());

        // Calculate dimensions
        int maxEffectWidth = 0;
        for (class_1293 effect : activeEffects) {
            var statusEffect = effect.method_5579();
            String effectName = statusEffect.comp_349().method_5560().getString();
            String amplifierText = effect.method_5578() > 0 ? " " + (effect.method_5578() + 1) : "";
            String timeText = formatDuration(effect);
            int effectWidth = textRenderer.method_27525(UiText.of(effectName + amplifierText + " " + timeText)) + 25;
            if (effectWidth > maxEffectWidth) {
                maxEffectWidth = effectWidth;
            }
        }

        int headerHeight = 12;
        int totalWidth = Math.max(maxEffectWidth + padding * 2, textRenderer.method_27525(UiText.of("Эффекты")) + padding * 2);
        int totalHeight = padding + headerHeight + 6 + (activeEffects.size() * 22) + padding;

        // Draw background
        RoundedUtils.drawRoundRect(context, x, y, totalWidth, totalHeight, 8, bgColor);

        // Draw Header (Title only, without square icon)
        int headerX = x + padding;
        int headerY = y + padding;

        context.method_51439(textRenderer, UiText.of("Эффекты"), headerX, headerY, textColor, false);

        // Draw effects
        int effectY = headerY + headerHeight + 6;

        for (class_1293 effect : activeEffects) {
            var statusEffect = effect.method_5579();
            String effectName = statusEffect.comp_349().method_5560().getString();
            String amplifierText = effect.method_5578() > 0 ? " " + (effect.method_5578() + 1) : "";
            String timeText = formatDuration(effect);

            int effectX = x + padding;

            // Стильный закругленный квадрат-иконка с первой буквой эффекта
            RoundedUtils.drawRoundRect(context, effectX, effectY, 16, 16, 4, accent);
            String iconChar = !effectName.isEmpty() ? effectName.substring(0, 1).toUpperCase() : "•";
            int charWidth = textRenderer.method_27525(UiText.of(iconChar));
            context.method_51439(textRenderer, UiText.of(iconChar), effectX + (16 - charWidth) / 2, effectY + 4, 0xFFFFFFFF, false);

            // Draw effect name and amplifier
            int nameX = effectX + 22;
            context.method_51439(textRenderer, UiText.of(effectName + amplifierText), nameX, effectY + 4, textColor, false);

            // Draw time after the text
            int timeX = nameX + textRenderer.method_27525(UiText.of(effectName + amplifierText)) + 10;
            context.method_51439(textRenderer, UiText.of(timeText), timeX, effectY + 4, applyAlpha(0xFF808080, getAlpha()), false);

            effectY += 22;
        }
    }

    private String formatDuration(class_1293 effect) {
        int duration = effect.method_5584();
        int seconds = duration / 20;
        int minutes = seconds / 60;
        int remainingSeconds = seconds % 60;

        if (minutes > 0) {
            return String.format("%d:%02d", minutes, remainingSeconds);
        } else {
            return String.format("%ds", remainingSeconds);
        }
    }

    private int applyAlpha(int color, float factor) {
        int a = (int) (((color >> 24) & 0xFF) * factor);
        return (color & 0x00FFFFFF) | (a << 24);
    }

    @Override
    public int getEditorWidth() { return (int) (150 * getScale()); }
    @Override
    public int getEditorHeight() { return (int) (100 * getScale()); }
}