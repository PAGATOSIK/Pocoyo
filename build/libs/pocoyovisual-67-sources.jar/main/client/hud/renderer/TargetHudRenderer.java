package main.client.hud.renderer;

import main.client.PocoyoVisual;
import main.client.hud.HudComponent;
import main.client.render.RoundedUtils;
import main.client.render.UiText;
import net.minecraft.class_10799;
import net.minecraft.class_1309;
import net.minecraft.class_1472;
import net.minecraft.class_1642;
import net.minecraft.class_1657;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_3532;
import net.minecraft.class_7532;

public class TargetHudRenderer extends HudComponent {

    private static final int BASE_BACKGROUND_COLOR = 0x00141414;
    private static final class_2960 ZOMBIE_TEXTURE = class_2960.method_60655("pocou", "texture/targethud/zombie.png");
    private static final class_2960 SHEEP_TEXTURE = class_2960.method_60655("pocou", "texture/targethud/sheep.png");

    private float animatedHealth = 0f;
    private class_1309 lastTarget = null;
    private long lastTargetTime = 0L;
    private float alpha = 0f;

    public TargetHudRenderer(int defaultX, int defaultY) {
        super("TargetHUD", defaultX, defaultY);
    }

    @Override
    public void render(class_332 context, float tickDelta) {
        var mc = class_310.method_1551();
        if (mc.field_1724 == null || mc.field_1687 == null) return;

        long currentTime = System.currentTimeMillis();

        class_1309 currentTarget = null;
        if (mc.field_1692 instanceof class_1309 living) {
            currentTarget = living;
        }

        if (currentTarget != null) {
            lastTarget = currentTarget;
            lastTargetTime = currentTime;
        } else {
            if (currentTime - lastTargetTime > 3L) {
                lastTarget = null;
            }
        }

        boolean editing = isEditing();
        float targetAlpha = (lastTarget != null || editing) ? 1.0f : 0.0f;
        alpha = class_3532.method_16439(tickDelta * 0.1f, alpha, targetAlpha);

        if (alpha <= 0.001f) return;

        int x = getX();
        int y = getY();
        int width = 155;
        int height = 42;

        context.method_51448().pushMatrix();
        context.method_51448().translate((float) x, (float) y);
        context.method_51448().scale(getScale(), getScale());
        context.method_51448().translate((float) -x, (float) -y);

        try {
            class_1309 targetToRender = lastTarget;
            var themeManager = PocoyoVisual.INSTANCE.getThemeManager();
            int accent = getAccentColor();

            float combinedAlpha = alpha * getAlpha();

            int bgColor = applyAlpha((0xFF << 24) | BASE_BACKGROUND_COLOR, combinedAlpha);
            int moduleBgColor = applyAlpha(themeManager.getModuleBgColor(), combinedAlpha);
            int accentColor = applyAlpha(accent, combinedAlpha);

            RoundedUtils.drawRoundRect(context, x, y, width, height, 8, bgColor);

            String name = targetToRender != null ? targetToRender.method_5477().getString() : "???";
            float health = targetToRender != null ? targetToRender.method_6032() : 67f;
            float maxHealth = targetToRender != null ? targetToRender.method_6063() : 67f;

            animatedHealth = class_3532.method_16439(tickDelta * 0.15f, animatedHealth, health);

            int headSize = 28;
            int headX = x + 7;
            int headY = y + (height - headSize) / 2;

            if (targetToRender instanceof class_1657 player) {
                var skinTextures = mc.method_1582().method_52862(player.method_7334());
                class_7532.method_52722(context, skinTextures, headX, headY, headSize);
            } else {
                class_2960 mobTexture = null;
                if (targetToRender instanceof class_1642) {
                    mobTexture = ZOMBIE_TEXTURE;
                } else if (targetToRender instanceof class_1472) {
                    mobTexture = SHEEP_TEXTURE;
                }

                if (mobTexture != null) {
                    drawMobTexture(context, mobTexture, headX, headY, headSize, combinedAlpha);
                } else {
                    RoundedUtils.drawRoundRect(context, headX, headY, headSize, headSize, 4, moduleBgColor);
                }
            }

            int textX = headX + headSize + 8;
            int textColor = applyAlpha(themeManager.getTextColor(), combinedAlpha);

            if (name.length() > 12) name = name.substring(0, 10) + "..";
            context.method_51439(mc.field_1772, UiText.of(name), textX, y + 8, textColor, false);

            String hpText = String.format("%.1f HP", health);
            int hpColor = applyAlpha((themeManager.getTextColor() & 0xFFFFFF) | 0x99000000, combinedAlpha);
            context.method_51439(mc.field_1772, UiText.of(hpText), x + width - mc.field_1772.method_1727(hpText) - 8, y + 8, hpColor, false);

            int barX = textX;
            int barY = y + 26;
            int barWidth = width - (barX - x) - 8;
            int barHeight = 6;

            RoundedUtils.drawRoundRect(context, barX, barY, barWidth, barHeight, 3, moduleBgColor);

            float healthPercent = class_3532.method_15363(animatedHealth / maxHealth, 0.0f, 1.0f);
            int currentBarWidth = (int) (barWidth * healthPercent);

            if (currentBarWidth > 0) {
                RoundedUtils.drawRoundRect(context, barX, barY, currentBarWidth, barHeight, 3, accentColor);
            }
        } finally {
            context.method_51448().popMatrix();
        }
    }

    private int applyAlpha(int color, float factor) {
        int a = (int) (((color >> 24) & 0xFF) * factor);
        return (color & 0x00FFFFFF) | (a << 24);
    }

    private boolean isEditing() {
        var mc = class_310.method_1551();
        return mc.field_1755 instanceof main.client.gui.HudEditorScreen;
    }

    private int getAccentColor() {
        if (PocoyoVisual.INSTANCE != null && PocoyoVisual.INSTANCE.getThemeManager() != null) {
            return PocoyoVisual.INSTANCE.getThemeManager().getAccentColor();
        }
        return 0xFF4BA5DE;
    }

    @Override
    public int getEditorWidth() { return (int) (155 * getScale()); }
    @Override
    public int getEditorHeight() { return (int) (42 * getScale()); }

    private void drawMobTexture(class_332 context, class_2960 texture, int x, int y, int size, float alpha) {
        context.method_25290(
                class_10799.field_56883,
                texture,
                x, y,
                0.0F, 0.0F,
                size, size, size, size
        );
    }
}